import{e as a,j as e}from"./index-ZwhE7Agc.js";import{X as l}from"./x-qIPfbL8i.js";/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=a("MailWarning",[["path",{d:"M22 10.5V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h12.5",key:"e61zoh"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}],["path",{d:"M20 14v4",key:"1hm744"}],["path",{d:"M20 22v.01",key:"12bgn6"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=a("Mail",[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",key:"18n3k1"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}]]),d=({title:t,message:s,setIsErrorVisible:r})=>e.jsx("div",{className:"fixed inset-0 z-40 flex items-center justify-center bg-black/50 backdrop-blur-sm",children:e.jsx("div",{className:"bg-white rounded-xl shadow-2xl w-96 p-8 transform transition-all duration-300 scale-100 animate-fade-in",children:e.jsxs("div",{className:"relative",children:[e.jsx("button",{onClick:()=>r(!1),className:"absolute -right-4 -top-4 p-2 bg-purple-100 rounded-full hover:bg-purple-200 transition-colors",children:e.jsx(l,{className:"w-4 h-4 text-purple-800"})}),e.jsxs("div",{className:"text-center space-y-4",children:[e.jsx("div",{className:"mx-auto w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center",children:e.jsx(i,{className:"w-8 h-8 text-purple-800"})}),e.jsx("h3",{className:"text-2xl font-bold text-gray-900",children:t}),e.jsx("p",{className:"text-gray-600",children:s})]})]})})});export{d as E,o as M};
